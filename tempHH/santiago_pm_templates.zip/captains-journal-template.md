# Captain's Journal Template

Notes.
