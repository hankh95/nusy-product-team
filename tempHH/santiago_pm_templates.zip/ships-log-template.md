# Ship's Log Template

Log entry template.
