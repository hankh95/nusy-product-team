# Crew Manifest Template

Agent role specification.
